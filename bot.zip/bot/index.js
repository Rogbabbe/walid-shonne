//Saker som man inte behöver röra
const Discord = require('discord.js')
const bot = new Discord.Client();
bot.login("NDUxMTA2MjMzNTQ2NTcxODEy.De9A8g.fpjYYDLzt7S7AmeD12RFQw-xlJo")

//Message Mention
bot.on('message', (message) => {
    
    if(message.content == '!rg') {
        message.reply('eyy kom till RG');
    }
});

//Message 
bot.on('message', (message) => {
    
    if(message.content == '!maxa') {
        message.channel.sendMessage('Jag kommer maxa dig jag vet vart din brevlåda bor');
    }

    if(message.content == '!invite') {
        message.channel.sendMessage('https://discordapp.com/oauth2/authorize?client_id=451106233546571812&scope=bot&permissions=2146958591');
    }

    if(message.content == '!bjud_in_till_kalas') {
        message.channel.sendMessage('https://discordapp.com/oauth2/authorize?client_id=451106233546571812&scope=bot&permissions=2146958591');
    }
});
